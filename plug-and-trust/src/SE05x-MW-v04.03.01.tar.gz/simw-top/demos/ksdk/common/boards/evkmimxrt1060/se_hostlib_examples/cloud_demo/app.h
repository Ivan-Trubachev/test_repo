/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 *
 * Copyright 2016-2017 NXP
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef _APP_H_
#define _APP_H_

/*******************************************************************************
 * Definitions
 ******************************************************************************/
/*${macro:start}*/

/*${macro:end}*/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
/*${prototype:start}*/
void BOARD_InitHardware(void);
/*${prototype:end}*/

#endif /* _APP_H_ */
